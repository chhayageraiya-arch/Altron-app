# Altron (Android starter)
Build: open this folder in Android Studio -> Run on your phone.
Setup in app: 1) Grant permissions 2) Enable Accessibility > Altron 3) (optional) paste Claude API key 4) Start Altron.
Say: "Altron, call Mom" / "Altron, text John saying I'm late" / "Altron, open WhatsApp" /
"Altron, set timer for 10 minutes" / "Altron, scroll down" / "Altron, click Send" / anything else (online).
Offline: install your language's offline speech pack (Settings > Google > Speech) for offline voice.
Calls and texts always ask you to say "yes" first.
Security: the API key is stored on-device in plain prefs; for anything beyond personal use, route through your own server.

## Offline talk (Altron baat karega bina internet)
1. Download a MediaPipe LLM model (.task), e.g. Gemma 3 1B int4, from huggingface.co/litert-community
2. Rename it to model.task and copy to: Android/data/com.altron.assistant/files/
3. Now without internet, anything that isn't a phone command is answered by Altron on-device and spoken aloud.
