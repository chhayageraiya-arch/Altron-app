plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.altron.assistant"
    compileSdk = 34
    defaultConfig { applicationId = "com.altron.assistant"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.core:core-ktx:1.13.1"); implementation("com.google.mediapipe:tasks-genai:0.10.14") }
