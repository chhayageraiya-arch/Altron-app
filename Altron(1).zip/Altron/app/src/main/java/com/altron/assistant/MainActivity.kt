package com.altron.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("altron", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        val key = EditText(this).apply {
            hint = "Claude API key (optional, enables online mode)"
            setText(prefs.getString("api_key", ""))
        }
        fun btn(label: String, f: () -> Unit) = Button(this).apply { text = label; setOnClickListener { f() } }
        root.addView(key)
        root.addView(btn("1. Grant permissions") {
            requestPermissions(arrayOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.SEND_SMS,
                Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS,
                Manifest.permission.POST_NOTIFICATIONS), 1)
        })
        root.addView(btn("2. Enable Accessibility (Altron)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(btn("3. Start Altron") {
            prefs.edit().putString("api_key", key.text.toString().trim()).apply()
            startForegroundService(Intent(this, AltronService::class.java))
        })
        root.addView(btn("Stop Altron") { stopService(Intent(this, AltronService::class.java)) })
        setContentView(root)
    }
}
