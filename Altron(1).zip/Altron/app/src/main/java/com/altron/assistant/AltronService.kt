package com.altron.assistant

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class AltronService : Service() {
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private lateinit var router: CommandRouter
    private val main = Handler(Looper.getMainLooper())
    private var speaking = false
    private var ttsReady = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("altron", "Altron", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "altron").setContentTitle("Altron is listening")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)

        tts = TextToSpeech(this) {
            ttsReady = it == TextToSpeech.SUCCESS
            if (ttsReady) { tts.language = Locale.getDefault(); speak("Altron online") }
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { speaking = false; main.post { listen() } }
            @Deprecated("") override fun onError(id: String?) { speaking = false; main.post { listen() } }
        })
        router = CommandRouter(this) { speak(it) }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply { setRecognitionListener(listener) }
        listen()
    }

    private fun speak(t: String) {
        if (!ttsReady) return
        speaking = true
        recognizer?.cancel()
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun listen() {
        if (speaking) return
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        recognizer?.startListening(i)
    }

    private val listener = object : RecognitionListener {
        override fun onResults(r: Bundle?) {
            val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (t != null && (CommandRouter.WAKE.containsMatchIn(t.lowercase()) || router.hasPending())) router.route(t)
            if (!speaking) main.postDelayed({ listen() }, 300)
        }
        override fun onError(e: Int) { if (!speaking) main.postDelayed({ listen() }, 500) }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
    }

    override fun onDestroy() { recognizer?.destroy(); tts.shutdown(); super.onDestroy() }
}
