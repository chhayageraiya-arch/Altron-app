package com.altron.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ClaudeClient {
    private const val SYSTEM = "You control an Android phone. Convert the user's command into ONE JSON object and output only JSON. " +
        "Schema: {\"action\":\"call|sms|open|click|type|scroll|back|home|reply\",\"name\":\"\",\"text\":\"\",\"app\":\"\",\"direction\":\"up|down\"}. " +
        "Use action reply with text for questions or chat."

    // Call from a background thread.
    fun plan(key: String, command: String): JSONObject {
        val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 300).put("system", SYSTEM)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", command)))
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 8000; c.readTimeout = 15000; c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val resp = c.inputStream.bufferedReader().readText()
        val text = JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
        return JSONObject(text.substring(text.indexOf('{'), text.lastIndexOf('}') + 1))
    }
}
