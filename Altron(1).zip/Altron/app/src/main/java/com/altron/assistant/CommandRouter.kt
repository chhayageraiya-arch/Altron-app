package com.altron.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.telephony.SmsManager
import org.json.JSONObject

class CommandRouter(private val ctx: Context, private val speak: (String) -> Unit) {
    companion object { val WAKE = Regex("\\bal+t?[ae]?r[ao]n\\b") }

    private val main = Handler(Looper.getMainLooper())
    private var pending: (() -> Unit)? = null
    private val brain = OfflineBrain(ctx)
    fun hasPending() = pending != null
    private val acc get() = AltronAccessibilityService.instance

    fun route(raw: String) {
        val t = raw.lowercase().replace(WAKE, "").trim().trimStart(',', ' ')
        pending?.let { p ->
            pending = null
            if (Regex("\\b(yes|yeah|confirm|do it)\\b").containsMatchIn(t)) p() else speak("Cancelled")
            return
        }
        // ---- Offline rules (always work) ----
        Regex("^(?:text|message|sms|send a message to|send message to)\\s+(.+?)\\s+(?:saying|say|that says|that)\\s+(.+)$")
            .find(t)?.let { smsContact(it.groupValues[1], it.groupValues[2]); return }
        Regex("^(?:call|phone|dial)\\s+(.+)$").find(t)?.let { callContact(it.groupValues[1]); return }
        Regex("^open\\s+(.+)$").find(t)?.let { openApp(it.groupValues[1]); return }
        Regex("^set (?:a )?timer for (\\d+) (second|minute|hour)s?").find(t)?.let {
            val n = it.groupValues[1].toInt()
            val s = when (it.groupValues[2]) { "hour" -> n * 3600; "minute" -> n * 60; else -> n }
            startActivity(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, s)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            speak("Timer set"); return
        }
        Regex("^set (?:an )?alarm (?:for|at) (\\d{1,2})(?::(\\d{2}))? ?(am|pm)?").find(t)?.let {
            var h = it.groupValues[1].toInt(); val m = it.groupValues[2].ifEmpty { "0" }.toInt()
            if (it.groupValues[3] == "pm" && h < 12) h += 12
            if (it.groupValues[3] == "am" && h == 12) h = 0
            startActivity(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
                .putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            speak("Alarm set"); return
        }
        Regex("^(?:click|tap|press)\\s+(.+)$").find(t)?.let { gui { acc!!.clickText(it.groupValues[1]) }; return }
        Regex("^type\\s+(.+)$").find(t)?.let { gui { acc!!.typeText(it.groupValues[1]) }; return }
        when {
            t.contains("go back") -> gui { acc!!.back() }
            t.contains("go home") -> gui { acc!!.home() }
            t.contains("scroll down") -> gui { acc!!.scroll(true) }
            t.contains("scroll up") -> gui { acc!!.scroll(false) }
            else -> askClaude(t)
        }
    }

    // ---- Online fallback for anything the rules don't cover ----
    private fun askClaude(cmd: String) {
        val key = ctx.getSharedPreferences("altron", Context.MODE_PRIVATE).getString("api_key", "") ?: ""
        if (key.isEmpty() || !online()) {
            if (!brain.available()) { speak("Offline chat ke liye model file chahiye. README dekho."); return }
            Thread {
                try { val r = brain.reply(cmd); main.post { speak(r) } }
                catch (e: Exception) { main.post { speak("Offline brain failed") } }
            }.start()
            return
        }
        Thread {
            try { val j = ClaudeClient.plan(key, cmd); main.post { execute(j) } }
            catch (e: Exception) { main.post { speak("Online request failed") } }
        }.start()
    }

    private fun execute(j: JSONObject) {
        val name = j.optString("name"); val text = j.optString("text")
        when (j.optString("action")) {
            "call" -> callContact(name)
            "sms" -> smsContact(name, text)
            "open" -> openApp(j.optString("app"))
            "click" -> gui { acc!!.clickText(text) }
            "type" -> gui { acc!!.typeText(text) }
            "scroll" -> gui { acc!!.scroll(j.optString("direction") != "up") }
            "back" -> gui { acc!!.back() }
            "home" -> gui { acc!!.home() }
            else -> speak(text.ifEmpty { "Done" })
        }
    }

    private fun gui(f: () -> Boolean) {
        if (acc == null) { speak("Please enable Altron in accessibility settings"); return }
        if (!f()) speak("I couldn't do that")
    }

    private fun callContact(name: String) {
        val num = findNumber(name) ?: run { speak("I can't find $name"); return }
        speak("Call $name? Say yes to confirm.")
        pending = {
            startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))))
        }
    }

    private fun smsContact(name: String, msg: String) {
        val num = findNumber(name) ?: run { speak("I can't find $name"); return }
        speak("Send $name the message: $msg. Say yes to confirm.")
        pending = {
            val sm = ctx.getSystemService(SmsManager::class.java)
            sm.sendMultipartTextMessage(num, null, sm.divideMessage(msg), null, null)
            speak("Sent")
        }
    }

    private fun openApp(name: String) {
        val pm = ctx.packageManager
        val app = pm.getInstalledApplications(0).firstOrNull {
            pm.getLaunchIntentForPackage(it.packageName) != null &&
                pm.getApplicationLabel(it).toString().contains(name, true)
        }
        val i = app?.let { pm.getLaunchIntentForPackage(it.packageName) }
        if (i != null) startActivity(i) else speak("I can't find $name")
    }

    private fun findNumber(name: String): String? {
        if (name.replace(" ", "").matches(Regex("\\+?\\d{5,}"))) return name.replace(" ", "")
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) }
        return null
    }

    private fun online(): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val c = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun startActivity(i: Intent) { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}
