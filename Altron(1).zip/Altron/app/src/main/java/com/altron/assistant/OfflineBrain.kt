package com.altron.assistant

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

/** On-device chat (no internet). Needs model.task in Android/data/com.altron.assistant/files/ */
class OfflineBrain(private val ctx: Context) {
    private val modelFile = File(ctx.getExternalFilesDir(null), "model.task")
    private var llm: LlmInference? = null

    fun available() = modelFile.exists()

    // Call from a background thread.
    fun reply(prompt: String): String {
        if (llm == null) {
            llm = LlmInference.createFromOptions(ctx,
                LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(modelFile.absolutePath).setMaxTokens(256).build())
        }
        return llm!!.generateResponse(
            "You are Altron, a friendly voice assistant. Reply in 1-2 short sentences, in the same language as the user.\nUser: $prompt\nAltron:"
        ).trim()
    }
}
